package com.example.foodwheel2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;
public class lottery extends AppCompatActivity {
    public ImageButton lottery;
    //public String member_id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lottery);
        lottery = findViewById(R.id.lottery_btn);

        //Bundle member = getIntent().getExtras();
        //member_id = member.getString("mid");
    }

    public void rotate(View view) {
        RotateAnimation rotateAnimation = new RotateAnimation(0, 720, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        lottery.setAnimation(rotateAnimation);
        rotateAnimation.setDuration(2000);
        rotateAnimation.setRepeatCount(2);
        lottery.startAnimation(rotateAnimation);

        rotateAnimation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                Intent result = new Intent(com.example.foodwheel2.lottery.this, result.class);
                //result.setClass(com.example.foodwheel2.lottery.this, com.example.foodwheel2.result.class);
                //Bundle bundle = new Bundle();
                //bundle.putString("mid",member_id);
                //result.putExtras(bundle);
                startActivity(result);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
    }
}
