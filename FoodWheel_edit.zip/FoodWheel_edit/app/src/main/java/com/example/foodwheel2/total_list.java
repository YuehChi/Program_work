package com.example.foodwheel2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class total_list extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_total_list);


    }
}
