package com.example.foodwheel2;

class HttpClient {
}
