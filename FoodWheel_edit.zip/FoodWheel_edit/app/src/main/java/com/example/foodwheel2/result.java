package com.example.foodwheel2;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
public class result extends AppCompatActivity {
    public TextView food_id,food_name, food_detail, food_evalutate, food_phone, food_time;
    public ImageView food_img;
    public RequestQueue mQueue, add_mQueue;
    public int index;
    public Button addBtn;
    public int member_id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        food_id = findViewById(R.id.rId);
        food_name = findViewById(R.id.text_food);
        food_detail = findViewById(R.id.textView6);
        food_img = findViewById(R.id.food_img);
        food_evalutate = findViewById(R.id.text_evalutate);
        food_phone = findViewById(R.id.text_tel);
        food_time = findViewById(R.id.text_time);
        mQueue = Volley.newRequestQueue(this);
        addBtn = findViewById(R.id.button2);
        add_mQueue = Volley.newRequestQueue(this);
        final RequestQueue add_request_queue = Volley.newRequestQueue(this);
        member_id = 2;
        //Bundle member = getIntent().getExtras();
        //String member_id = member.getString("mid");
//        new myAsyncTask().execute();
        String url = "https://misproject109.000webhostapp.com/restaurant_info.php";
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("restaurant");
                            String i = String.valueOf((int)(Math.random()*11));
//                          JSONArray employee = jsonArray.getJSONArray(i);
                            int j = (int)(Math.random()*11);
                            index = j;
                            JSONObject restaurant = jsonArray.getJSONObject(j);
                            int restaurant_id = restaurant.getInt("rId");
                            String restaurant_name = restaurant.getString("rName");
                            //Log.d("test", "restaurant_name = " + restaurant_name);
                            String restaurant_address = restaurant.getString("rSite");
                            String time = restaurant.getString("rTime");
                            String restaurant_phone = restaurant.getString("rTel");
                            String img_url = restaurant.getString("rImg");
                            String evalutate = restaurant.getString("rValue");
                            food_id.setText(String.valueOf(restaurant_id));
                            food_name.setText(restaurant_name);
                            food_detail.setText(restaurant_address);
                            food_phone.setText(restaurant_phone);
                            food_time.setText(time);
                            food_evalutate.setText("評價: "+evalutate);
                            new DownloadImageTask(food_img).execute(img_url);
//                            Toast.makeText(result.this,"GET success, rId = "+restaurant_id,Toast.LENGTH_SHORT).show();
//                            Toast.makeText(result.this,"GET success, i = "+i,Toast.LENGTH_SHORT).show();
//                            Toast.makeText(result.this,"GET success, mId = "+member_id,Toast.LENGTH_SHORT).show();
//                                if (restaurant_name!=null){
//                                    Log.d("TAG","table_data1 not null");
//                                }
//                                else {
//                                    Log.d("TAG","table_data1 null");
//                                }
                        }catch (JSONException e){
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        mQueue.add(request);
        final String add_url = "https://misproject109.000webhostapp.com/restaurant_favorite_insert.php";
        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StringRequest postRequest = new StringRequest(
                        Request.Method.POST,
                        add_url,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                try {
                                    JSONObject responseJsonObj = new JSONObject(response);
                                    int code_number = responseJsonObj.getInt("code");
                                    Log.d("check","code="+code_number);
                                    Toast.makeText(result.this,"GET code= "+code_number,Toast.LENGTH_SHORT).show();
                                    Toast.makeText(result.this,"Add Success",Toast.LENGTH_SHORT).show();
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                Log.d("Response", response.toString());
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                Log.d("volley", "Error: " + error.getMessage());
                                error.printStackTrace();
                            }
                        }) {
                    @Override
                    public String getBodyContentType() {
                        return "application/x-www-form-urlencoded; charset=UTF-8";
                    }
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String, String> params = new HashMap<String, String>();
                        params.put("mId", "2");
                        Log.d("rId", food_id.getText().toString());
                        params.put("rId", food_id.getText().toString());
                        return params;
                    }
                };
                add_request_queue.add(postRequest);
            }
        });
    }
    public void back(View view){
        Intent lottery = new Intent(this, com.example.foodwheel2.lottery.class);
        startActivity(lottery);
    }
    static class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {
        ImageView bmImage;
        public DownloadImageTask(ImageView bmImage) {
            this.bmImage = bmImage;
        }
        protected Bitmap doInBackground(String... urls) {
            String urldisplay = urls[0];
            Bitmap mIcon11 = null;
            try {
                InputStream in = new java.net.URL(urldisplay).openStream();
                mIcon11 = BitmapFactory.decodeStream(in);
            } catch (Exception e) {
                Log.e("Error", e.getMessage());
                e.printStackTrace();
            }
            return mIcon11;
        }
        protected void onPostExecute(Bitmap result) {
            bmImage.setImageBitmap(result);
        }
    }
}
